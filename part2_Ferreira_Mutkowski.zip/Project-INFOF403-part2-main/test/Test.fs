BEGIN Test

test1 :=4
test2
3est
012

END