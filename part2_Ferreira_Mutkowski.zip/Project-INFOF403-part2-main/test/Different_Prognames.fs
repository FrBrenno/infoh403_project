BEGIN FACTORIAL, Factorial, FaCTORIAL, Fact0rial, fAct0rial,

END


